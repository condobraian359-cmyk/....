package com.aiauto.axrunner

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Surface
import android.view.TextureView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File
import java.util.Locale

private val BG = Color(0xFF0E140F)
private val SURFACE = Color(0xFF1A221C)
private val GREEN = Color(0xFF19F04A)
private val GREEN_DARK = Color(0xFF00330D)
private val MUTED = Color(0xFF9DB0A1)
private val DANGER = Color(0xFFFF8A80)

data class HomeInfo(
    val running: Boolean = false,
    val engine: String = "…",
    val uid: String = "—",
    val pid: String = "—",
    val uptime: String = "—",
    val ver: String = "—",
    val selinux: String = "—",
    val shizukuStatus: String = "Comprobando…",
    val rootStatus: String = "Comprobando…"
)

class MainActivity : ComponentActivity() {
    private var tab by mutableIntStateOf(0)
    private var info by mutableStateOf(HomeInfo())
    private val mods = mutableStateListOf<Module>()
    private var busy by mutableStateOf(false)
    private var msg by mutableStateOf<String?>(null)
    private var heroDialog by mutableStateOf(false)
    private var heroVer by mutableIntStateOf(0)
    private var prefTick by mutableIntStateOf(0)
    private var deleting by mutableStateOf<Module?>(null)
    private var autostarted = false
    private var pendingBanner: String? = null

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refreshAll() }
    private val binderListener = Shizuku.OnBinderReceivedListener { refreshAll() }
    private val deadListener = Shizuku.OnBinderDeadListener { refreshAll() }

    private val zipPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) installZip(uri)
    }
    private val heroPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) saveHero(uri)
    }
    private val bannerPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val id = pendingBanner
        if (uri != null && id != null) saveBanner(id, uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shell.init(applicationContext)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = GREEN, onPrimary = GREEN_DARK,
                    background = BG, surface = SURFACE,
                    onSurface = Color.White, onBackground = Color.White
                )
            ) { AppRoot() }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ lógica

    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    private fun loadInfo(): HomeInfo {
        val b = Shell.current()
        val running = b !== LocalBackend
        val uid = when {
            b === ShizukuBackend -> try { Shizuku.getUid().toString() } catch (_: Throwable) { "—" }
            b === RootBackend -> "0"
            else -> "—"
        }
        val ver = if (b === ShizukuBackend) try { Shizuku.getVersion().toString() } catch (_: Throwable) { "—" } else "—"
        var pid = "—"
        var up = "—"
        if (running) {
            val r = Shell.run("ps -A -o PID,ETIME,ARGS 2>/dev/null | grep '[s]hizuku_server' | head -n 1")
            val parts = r.out.trim().split(Regex("\\s+"))
            if (parts.size >= 2 && parts[0].isNotEmpty() && parts[0].all { it.isDigit() }) {
                pid = parts[0]
                up = parts[1]
            }
        }
        val selinux = Shell.run("id -Z").out.trim().ifEmpty { "—" }
        val sh = ShizukuBackend
        val shText = when {
            !sh.binderReady() -> "no está en marcha (ábrelo y arráncalo)"
            sh.granted() -> "listo ✓"
            else -> "en marcha, falta dar permiso a esta app"
        }
        val rootText = if (RootBackend.available()) "disponible ✓" else "no disponible"
        val engine = when {
            b === ShizukuBackend -> "Shizuku"
            b === RootBackend -> "Root"
            else -> "Local"
        }
        return HomeInfo(running, engine, uid, pid, up, ver, selinux, shText, rootText)
    }

    private fun refreshAll() {
        Thread {
            try { ModuleStore.ensureAssets(this) } catch (_: Throwable) {}
            val list = try { ModuleStore.list(this) } catch (_: Throwable) { emptyList() }
            val i = loadInfo()
            runOnUiThread {
                mods.clear()
                mods.addAll(list)
                info = i
            }
            if (!autostarted && list.isNotEmpty()) {
                autostarted = true
                startAll(false)
            }
        }.start()
    }

    private fun startAll(manual: Boolean) {
        Thread {
            if (Shell.current() === LocalBackend && !manual) return@Thread
            val enabled = ModuleStore.list(this).filter { it.enabled }
            for (m in enabled) ModuleStore.start(m.id)
            if (manual) toast("Iniciados: ${enabled.size}")
        }.start()
    }

    private fun installZip(uri: Uri) {
        busy = true
        Thread {
            try {
                val id = ModuleStore.install(this, uri)
                ModuleStore.start(id)
                toast("Plugin instalado: $id")
            } catch (e: Throwable) {
                toast("No se pudo instalar: ${e.message}")
            }
            runOnUiThread { busy = false; tab = 1 }
            refreshAll()
        }.start()
    }

    private fun toggle(m: Module, on: Boolean) {
        ModuleStore.setEnabled(this, m.id, on)
        val idx = mods.indexOfFirst { it.id == m.id }
        if (idx >= 0) mods[idx] = m.copy(enabled = on)
        Thread {
            if (on) {
                val x = ModuleStore.start(m.id)
                if (x.code != 0) toast("Error: ${x.err.trim()}")
            } else {
                ModuleStore.stop(m.id)
            }
        }.start()
    }

    private fun runAction(m: Module) {
        busy = true
        Thread {
            val r = ModuleStore.action(m.id)
            val text = (r.out + r.err).trim().ifEmpty { "Hecho" }
            runOnUiThread { busy = false; msg = text }
        }.start()
    }

    private fun openWeb(m: Module) {
        startActivity(Intent(this, WebUiActivity::class.java).putExtra("id", m.id))
    }

    private fun saveBanner(id: String, uri: Uri) {
        Thread {
            try {
                ModuleStore.setCustomBanner(this, id, uri)
                refreshAll()
            } catch (e: Throwable) {
                toast("No se pudo usar la imagen: ${e.message}")
            }
        }.start()
    }

    private fun clearBanner(id: String) {
        ModuleStore.clearCustomBanner(this, id)
        refreshAll()
    }

    private fun heroFile(): Pair<File, String>? {
        val p = getSharedPreferences("axr", MODE_PRIVATE)
        val name = p.getString("hero_file", null) ?: return null
        val f = File(filesDir, name)
        if (!f.exists()) return null
        return f to (p.getString("hero_type", "image") ?: "image")
    }

    private fun saveHero(uri: Uri) {
        Thread {
            try {
                val type = contentResolver.getType(uri) ?: ""
                val kind = when {
                    type.startsWith("video/") -> "video"
                    type.startsWith("image/") -> "image"
                    else -> throw Exception("Elige una imagen o un video")
                }
                val name = "hero_" + System.currentTimeMillis()
                val dst = File(filesDir, name)
                val input = contentResolver.openInputStream(uri) ?: throw Exception("No se pudo abrir el archivo")
                input.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
                val p = getSharedPreferences("axr", MODE_PRIVATE)
                val old = p.getString("hero_file", null)
                p.edit().putString("hero_file", name).putString("hero_type", kind).apply()
                if (old != null) File(filesDir, old).delete()
                runOnUiThread { heroVer++ }
            } catch (e: Throwable) {
                toast("No se pudo usar el archivo: ${e.message}")
            }
        }.start()
    }

    private fun clearHero() {
        val p = getSharedPreferences("axr", MODE_PRIVATE)
        val old = p.getString("hero_file", null)
        p.edit().remove("hero_file").remove("hero_type").apply()
        if (old != null) File(filesDir, old).delete()
        heroVer++
    }

    private fun askShizuku() {
        try {
            if (!ShizukuBackend.binderReady()) { toast("Abre Shizuku y arráncalo primero"); return }
            if (Shizuku.isPreV11()) { toast("Tu Shizuku es muy antiguo: actualízalo"); return }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                toast("Ya tiene permiso"); return
            }
            Shizuku.requestPermission(100)
        } catch (e: Throwable) { toast("Shizuku: ${e.message}") }
    }

    // ------------------------------------------------------------------ interfaz

    @Composable
    private fun AppRoot() {
        Box(Modifier.fillMaxSize().background(BG)) {
            Crossfade(targetState = tab, label = "tab") { t ->
                when (t) {
                    0 -> HomeScreen()
                    1 -> PluginsScreen()
                    else -> SettingsScreen()
                }
            }
            if (busy) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
                    color = GREEN, trackColor = Color.Transparent
                )
            }
            Row(
                Modifier.align(Alignment.BottomCenter).padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BottomNav()
                if (tab != 2) {
                    Box(
                        Modifier.size(60.dp).clip(CircleShape).background(Color(0xFF0F8A22))
                            .clickable { zipPicker.launch(arrayOf("*/*")) },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                }
            }
        }

        val m = msg
        if (m != null) {
            AlertDialog(
                onDismissRequest = { msg = null },
                containerColor = SURFACE,
                confirmButton = { TextButton(onClick = { msg = null }) { Text("Cerrar", color = GREEN) } },
                text = { Text(m, color = Color.White, modifier = Modifier.verticalScroll(rememberScrollState())) }
            )
        }
        val del = deleting
        if (del != null) {
            AlertDialog(
                onDismissRequest = { deleting = null },
                containerColor = SURFACE,
                title = { Text("Eliminar ${del.name}", color = Color.White) },
                text = { Text("Se ejecuta su uninstall.sh (si lo tiene) y se borra.", color = MUTED) },
                confirmButton = {
                    TextButton(onClick = {
                        deleting = null
                        Thread { ModuleStore.remove(this@MainActivity, del.id); refreshAll() }.start()
                    }) { Text("Eliminar", color = DANGER) }
                },
                dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancelar", color = MUTED) } }
            )
        }
        if (heroDialog) {
            AlertDialog(
                onDismissRequest = { heroDialog = false },
                containerColor = SURFACE,
                title = { Text("Fondo de la tarjeta", color = Color.White) },
                text = { Text("Pon una imagen o un video propio. El video se repite sin sonido; mejor corto y ligero para no gastar batería.", color = MUTED) },
                confirmButton = {
                    TextButton(onClick = {
                        heroDialog = false
                        heroPicker.launch(arrayOf("image/*", "video/*"))
                    }) { Text("Elegir imagen o video", color = GREEN) }
                },
                dismissButton = {
                    TextButton(onClick = { heroDialog = false; clearHero() }) { Text("Quitar fondo", color = DANGER) }
                }
            )
        }
    }

    @Composable
    private fun BottomNav() {
        val items = listOf("🏠" to "Inicio", "🧩" to "Plugins", "⚙️" to "Ajustes")
        Row(
            Modifier.clip(RoundedCornerShape(36.dp)).background(Color(0xF02A3A2D)).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { i, item ->
                val sel = tab == i
                Row(
                    Modifier.clip(RoundedCornerShape(30.dp))
                        .background(if (sel) GREEN else Color.Transparent)
                        .clickable { tab = i }
                        .padding(horizontal = if (sel) 18.dp else 14.dp, vertical = 12.dp)
                        .animateContentSize(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(item.first, fontSize = 20.sp)
                    if (sel) {
                        Spacer(Modifier.width(6.dp))
                        Text(item.second, color = GREEN_DARK, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- Inicio

    @Composable
    private fun HomeScreen() {
        val version = remember {
            try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (_: Throwable) { "" }
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painterResource(R.drawable.cat_logo), "Logo",
                        Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Ax Runner", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("v$version · módulos con Shizuku o root", fontSize = 12.sp, color = MUTED)
                    }
                }
            }
            item { HeroCard() }
            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(SURFACE).padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCell("▶", "Activos", mods.count { it.enabled }.toString(), Modifier.weight(1f))
                    StatCell("🧩", "Plugins", mods.size.toString(), Modifier.weight(1f))
                }
            }
            item { SectionTitle("Información del dispositivo") }
            item {
                val device = Build.MANUFACTURER.replaceFirstChar { it.uppercase() } + " " + Build.MODEL
                Panel {
                    Row(Modifier.fillMaxWidth()) {
                        InfoCell("Dispositivo", device, Modifier.weight(1f))
                        InfoCell("Android", "${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})", Modifier.weight(1f))
                    }
                    Divider()
                    Row(Modifier.fillMaxWidth()) {
                        InfoCell("Parche de seguridad", Build.VERSION.SECURITY_PATCH, Modifier.weight(1f))
                        InfoCell("Kernel", System.getProperty("os.version") ?: "—", Modifier.weight(1f))
                    }
                    Divider()
                    Row(Modifier.fillMaxWidth()) {
                        InfoCell("ABI", Build.SUPPORTED_ABIS.firstOrNull() ?: "—", Modifier.weight(1f))
                        InfoCell("Contexto SELinux", info.selinux, Modifier.weight(1f))
                    }
                }
            }
        }
    }

    @Composable
    private fun HeroCard() {
        val hero = remember(heroVer) { heroFile() }
        Box(
            Modifier.fillMaxWidth().height(216.dp).clip(RoundedCornerShape(30.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF17A82D), Color(0xFF0A5A18))))
        ) {
            if (hero != null) {
                if (hero.second == "video") LoopVideo(hero.first, Modifier.matchParentSize())
                else SampledImage(hero.first, Modifier.matchParentSize(), 1080)
                Box(
                    Modifier.matchParentSize()
                        .background(Brush.verticalGradient(listOf(Color(0x22000000), Color(0x88000000))))
                )
            }
            Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (info.running) "Running" else "Detenido",
                            fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Color.White
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Tag("UID", info.uid)
                            Tag("MOTOR", info.engine)
                        }
                    }
                    RoundIcon(Icons.Filled.Refresh) { refreshAll() }
                    Spacer(Modifier.width(8.dp))
                    RoundIcon(Icons.Filled.Edit) { heroDialog = true }
                }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                        .background(Color(0x66000000)).padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    HeroStat("Tiempo", info.uptime)
                    HeroStat("PID", info.pid)
                    HeroStat("Ver", info.ver)
                }
            }
        }
    }

    // ---------------------------------------------------------------- Plugins

    @Composable
    private fun PluginsScreen() {
        var q by remember { mutableStateOf("") }
        val shown = mods.filter { it.name.contains(q, true) || it.desc.contains(q, true) }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Text("Plugins", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White) }
            item {
                TextField(
                    value = q, onValueChange = { q = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    placeholder = { Text("Buscar plugin", color = MUTED) },
                    leadingIcon = { Icon(Icons.Filled.Search, null, tint = MUTED) },
                    shape = RoundedCornerShape(28.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = SURFACE, unfocusedContainerColor = SURFACE,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = GREEN, focusedTextColor = Color.White, unfocusedTextColor = Color.White
                    )
                )
            }
            if (shown.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth().padding(top = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(
                            painterResource(R.drawable.cat_logo), null,
                            Modifier.size(96.dp).clip(RoundedCornerShape(28.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(Modifier.height(14.dp))
                        Text("Aún no hay plugins", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(
                            "Toca + para instalar un módulo (.zip)",
                            fontSize = 14.sp, color = MUTED, textAlign = TextAlign.Center
                        )
                    }
                }
            }
            items(shown, key = { it.id }) { m -> PluginCard(m) }
        }
    }

    @Composable
    private fun PluginCard(m: Module) {
        var open by remember(m.id) { mutableStateOf(false) }
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF24382A), Color(0xFF16221A))))
                .clickable { open = !open }
                .animateContentSize()
        ) {
            val b = m.banner
            if (b != null) SampledImage(b, Modifier.matchParentSize(), 900)
            Box(
                Modifier.matchParentSize()
                    .background(Brush.verticalGradient(listOf(Color(0x55000000), Color(0xBB0E140F))))
            )
            Column(Modifier.padding(18.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (m.sizeKb >= 0) Pill(fmtSize(m.sizeKb), Color(0x99000000), Color.White)
                        if (m.hasWeb) Pill("WEBUI", Color(0xFF0B7A1E), Color.White)
                        if (m.hasAction) Pill("ACTION", Color(0x99000000), Color.White)
                    }
                    Switch(
                        checked = m.enabled, onCheckedChange = { on -> toggle(m, on) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = GREEN_DARK, checkedTrackColor = GREEN,
                            uncheckedThumbColor = MUTED, uncheckedTrackColor = Color(0x66000000),
                            uncheckedBorderColor = MUTED
                        )
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(m.name, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Versión: ${m.version}", fontSize = 14.sp, color = Color(0xFFD5E2D8))
                if (m.author.isNotEmpty()) Text("Autor: ${m.author}", fontSize = 14.sp, color = Color(0xFFD5E2D8))
                if (m.desc.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        m.desc, fontSize = 14.sp, color = Color(0xFFE6EEE8),
                        maxLines = if (open) 12 else 3, overflow = TextOverflow.Ellipsis
                    )
                }
                AnimatedVisibility(
                    visible = open,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Row(
                        Modifier.padding(top = 14.dp).horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (m.hasWeb) ActionPill("WebUI") { openWeb(m) }
                        if (m.hasAction) ActionPill("Acción") { runAction(m) }
                        ActionPill("Iniciar") {
                            Thread {
                                val x = ModuleStore.start(m.id)
                                toast(if (x.code == 0) "Iniciado" else "Error: ${x.err.trim()}")
                            }.start()
                        }
                        ActionPill("Detener") { Thread { ModuleStore.stop(m.id); toast("Detenido") }.start() }
                        ActionPill("Cambiar imagen") {
                            pendingBanner = m.id
                            bannerPicker.launch(arrayOf("image/*"))
                        }
                        if (m.customBanner) ActionPill("Quitar imagen") { clearBanner(m.id) }
                        ActionPill("Eliminar", danger = true) { deleting = m }
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- Ajustes

    @Composable
    private fun SettingsScreen() {
        val pref = remember(prefTick) { Shell.pref() }
        val options = listOf(
            "auto" to "Automático (recomendado)",
            "shizuku" to "Shizuku",
            "root" to "Root",
            "local" to "Local (solo pruebas)"
        )
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Text("Ajustes", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White) }
            item {
                Panel {
                    SectionTitle("Motor de ejecución")
                    options.forEach { opt ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                .clickable { Shell.setPref(opt.first); prefTick++; refreshAll() },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = pref == opt.first,
                                onClick = { Shell.setPref(opt.first); prefTick++; refreshAll() },
                                colors = RadioButtonDefaults.colors(selectedColor = GREEN, unselectedColor = MUTED)
                            )
                            Text(opt.second, color = Color.White, fontSize = 15.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("• Shizuku: ${info.shizukuStatus}", color = MUTED, fontSize = 13.sp)
                    Text("• Root: ${info.rootStatus}", color = MUTED, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    BigButton("Permiso Shizuku") { askShizuku() }
                }
            }
            item {
                Panel {
                    SectionTitle("Tarjeta principal")
                    Text(
                        "Pon una imagen o un video de fondo en la tarjeta verde de Inicio.",
                        color = MUTED, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    BigButton("Elegir imagen o video") { heroPicker.launch(arrayOf("image/*", "video/*")) }
                    Spacer(Modifier.height(8.dp))
                    BigButton("Quitar fondo", ghost = true) { clearHero() }
                }
            }
            item {
                Panel {
                    SectionTitle("Plugins")
                    Text(
                        "Los plugins activados se inician solos al abrir la app. Aquí puedes iniciarlos ahora.",
                        color = MUTED, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    BigButton("Iniciar activos ahora") { startAll(true) }
                }
            }
            item {
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painterResource(R.drawable.cat_logo), null,
                            Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("Ax Runner", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                            Text("Los plugins viven en /data/local/tmp/axr/", fontSize = 12.sp, color = MUTED)
                        }
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- piezas

    private fun fmtSize(kb: Long): String =
        if (kb >= 1024) String.format(Locale.US, "%.2f MB", kb / 1024.0) else "$kb KB"

    @Composable
    private fun Panel(content: @Composable ColumnScope.() -> Unit) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(SURFACE).padding(18.dp),
            content = content
        )
    }

    @Composable
    private fun SectionTitle(text: String) {
        Text(text, color = GREEN, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
    }

    @Composable
    private fun Divider() {
        Box(Modifier.fillMaxWidth().padding(vertical = 12.dp).height(1.dp).background(Color(0x22FFFFFF)))
    }

    @Composable
    private fun InfoCell(label: String, value: String, modifier: Modifier) {
        Column(modifier) {
            Text(label, fontSize = 12.sp, color = MUTED)
            Text(value, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White, maxLines = 2)
        }
    }

    @Composable
    private fun StatCell(icon: String, label: String, value: String, modifier: Modifier) {
        Row(modifier, verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F3A19)),
                contentAlignment = Alignment.Center
            ) { Text(icon, fontSize = 22.sp) }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(label, fontSize = 13.sp, color = MUTED)
                Text(value, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = GREEN)
            }
        }
    }

    @Composable
    private fun Tag(label: String, value: String) {
        Row(Modifier.height(28.dp).clip(RoundedCornerShape(50)), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.fillMaxHeight().background(Color(0xFF0B3D14)).padding(horizontal = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(label, color = GREEN, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            Box(
                Modifier.fillMaxHeight().background(GREEN).padding(horizontal = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(value, color = GREEN_DARK, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        }
    }

    @Composable
    private fun HeroStat(label: String, value: String) {
        Column {
            Text(label, fontSize = 11.sp, color = Color(0xB3FFFFFF))
            Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }

    @Composable
    private fun RoundIcon(icon: ImageVector, onClick: () -> Unit) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(Color(0x55000000)).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
    }

    @Composable
    private fun Pill(text: String, bg: Color, fg: Color) {
        Text(
            text, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }

    @Composable
    private fun ActionPill(text: String, danger: Boolean = false, onClick: () -> Unit) {
        Text(
            text, color = if (danger) DANGER else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.clip(RoundedCornerShape(50)).background(Color(0x77000000))
                .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp)
        )
    }

    @Composable
    private fun BigButton(text: String, ghost: Boolean = false, onClick: () -> Unit) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(50))
                .background(if (ghost) Color(0xFF26352A) else GREEN)
                .clickable(onClick = onClick).padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(text, color = if (ghost) Color.White else GREEN_DARK, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}

// -------------------------------------------------------------------- imágenes y video

private fun decodeSampled(f: File, reqW: Int): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.absolutePath, o)
    var s = 1
    while (o.outWidth / (s * 2) >= reqW) s *= 2
    BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = s })
} catch (_: Throwable) { null }

@Composable
private fun SampledImage(file: File, modifier: Modifier, maxW: Int) {
    val bmp by produceState<ImageBitmap?>(null, file.absolutePath, file.lastModified()) {
        value = withContext(Dispatchers.IO) { decodeSampled(file, maxW)?.asImageBitmap() }
    }
    bmp?.let { Image(it, null, modifier, contentScale = ContentScale.Crop) }
}

/** Video en bucle, sin sonido, recortado para llenar el espacio (como una imagen "crop"). */
@Composable
private fun LoopVideo(file: File, modifier: Modifier) {
    AndroidView(modifier = modifier, factory = { ctx ->
        val tv = TextureView(ctx)
        var mp: MediaPlayer? = null

        fun fit(vw: Int, vh: Int) {
            val w = tv.width.toFloat()
            val h = tv.height.toFloat()
            if (vw <= 0 || vh <= 0 || w <= 0f || h <= 0f) return
            val va = vw.toFloat() / vh
            val ra = w / h
            val m = Matrix()
            if (va > ra) m.setScale(va / ra, 1f, w / 2f, h / 2f) else m.setScale(1f, ra / va, w / 2f, h / 2f)
            tv.setTransform(m)
        }

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
                try {
                    val p = MediaPlayer()
                    p.setDataSource(file.absolutePath)
                    p.setSurface(Surface(st))
                    p.isLooping = true
                    p.setVolume(0f, 0f)
                    p.setOnVideoSizeChangedListener { _, vw, vh -> fit(vw, vh) }
                    p.setOnPreparedListener { it.start() }
                    p.setOnErrorListener { _, _, _ -> true }
                    p.prepareAsync()
                    mp = p
                } catch (_: Throwable) {}
            }

            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {
                mp?.let { fit(it.videoWidth, it.videoHeight) }
            }

            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                try { mp?.release() } catch (_: Throwable) {}
                mp = null
                return true
            }

            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        tv
    })
}
