package com.aiauto.axrunner

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.zip.ZipFile

data class Module(
    val id: String, val name: String, val version: String,
    val author: String, val desc: String,
    val hasWeb: Boolean, val hasAction: Boolean,
    val sizeKb: Long,
    val enabled: Boolean,
    val banner: File?,          // imagen del plugin (la suya o la que eligió el usuario)
    val customBanner: Boolean
)

/**
 * Los módulos se despliegan en /data/local/tmp/axr/<id>/ (lo puede leer el shell de ADB)
 * y su carpeta webroot también se copia a la app para mostrarla en el WebView.
 */
object ModuleStore {
    const val DEPLOY = "/data/local/tmp/axr"
    private val SAFE = Regex("^[A-Za-z0-9._/ -]+$")
    private val SAFE_ID = Regex("^[A-Za-z0-9_.-]+$")
    private val BANNER_NAMES = listOf("banner.jpg", "banner.jpeg", "banner.png", "banner.webp")

    fun modsDir(ctx: Context) = File(ctx.filesDir, "mods")
    fun uiDir(ctx: Context, id: String) = File(ctx.filesDir, "ui/$id")
    fun ownBanner(ctx: Context, id: String) = File(modsDir(ctx), "$id/banner.img")
    fun customBannerFile(ctx: Context, id: String) = File(ctx.filesDir, "banners/$id.img")
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("axr", Context.MODE_PRIVATE)

    fun parseProps(text: String): Map<String, String> =
        text.lines().mapNotNull { l ->
            val i = l.indexOf('=')
            if (i > 0 && !l.trimStart().startsWith("#")) l.substring(0, i).trim() to l.substring(i + 1).trim() else null
        }.toMap()

    fun enabled(ctx: Context, id: String): Boolean = prefs(ctx).getBoolean("en_$id", true)
    fun setEnabled(ctx: Context, id: String, on: Boolean) { prefs(ctx).edit().putBoolean("en_$id", on).apply() }

    fun list(ctx: Context): List<Module> {
        val dirs = modsDir(ctx).listFiles() ?: return emptyList()
        val p = prefs(ctx)
        return dirs.filter { File(it, "module.prop").exists() }.sortedBy { it.name }.map { d ->
            val props = parseProps(File(d, "module.prop").readText())
            val custom = customBannerFile(ctx, d.name)
            val own = ownBanner(ctx, d.name)
            Module(
                id = d.name,
                name = props["name"] ?: d.name,
                version = props["version"] ?: "?",
                author = props["author"] ?: "",
                desc = props["description"] ?: "",
                hasWeb = File(uiDir(ctx, d.name), "index.html").exists(),
                hasAction = p.getBoolean("act_${d.name}", false),
                sizeKb = p.getLong("size_${d.name}", -1L),
                enabled = p.getBoolean("en_${d.name}", true),
                banner = if (custom.exists()) custom else if (own.exists()) own else null,
                customBanner = custom.exists()
            )
        }
    }

    /**
     * Completa lo que falte de los módulos ya instalados (tamaño, si tienen acción, imagen del plugin),
     * leyéndolo de la carpeta de despliegue. Se ejecuta en segundo plano.
     */
    fun ensureAssets(ctx: Context) {
        val p = prefs(ctx)
        val dirs = modsDir(ctx).listFiles() ?: return
        val canRead = Shell.current() !== LocalBackend
        for (d in dirs) {
            val id = d.name
            val pf = File(d, "module.prop")
            if (!pf.exists() || !SAFE_ID.matches(id) || !canRead) continue
            if (!p.contains("size_$id")) {
                val r = Shell.run("cd '$DEPLOY/$id' 2>/dev/null && echo \"SIZE=\$(du -sk . | cut -f1)\" && ([ -f action.sh ] && echo ACTION=1); true")
                val lines = r.out.lines().map { it.trim() }
                val size = lines.firstOrNull { it.startsWith("SIZE=") }?.removePrefix("SIZE=")?.toLongOrNull()
                if (size != null) {
                    p.edit().putLong("size_$id", size).putBoolean("act_$id", lines.any { it == "ACTION=1" }).apply()
                }
            }
            val bf = ownBanner(ctx, id)
            if (!bf.exists() && !p.getBoolean("bn_$id", false)) {
                val props = parseProps(pf.readText())
                val cands = (listOfNotNull(props["banner"]?.removePrefix("./")) + BANNER_NAMES).distinct()
                for (c in cands) {
                    if (c.contains("..") || !SAFE.matches(c)) continue
                    val r = Shell.run("cat '$DEPLOY/$id/$c'")
                    if (r.code == 0 && r.raw.size > 200) { bf.writeBytes(r.raw); break }
                }
                p.edit().putBoolean("bn_$id", true).apply()
            }
        }
    }

    /** Guarda una imagen elegida por el usuario como imagen del plugin. */
    fun setCustomBanner(ctx: Context, id: String, uri: Uri) {
        val dst = customBannerFile(ctx, id)
        dst.parentFile?.mkdirs()
        val input = ctx.contentResolver.openInputStream(uri) ?: throw Exception("No se pudo abrir la imagen")
        input.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
    }

    fun clearCustomBanner(ctx: Context, id: String) { customBannerFile(ctx, id).delete() }

    /** Instala un .zip de módulo. Devuelve el id o lanza una excepción con el motivo. */
    fun install(ctx: Context, zipUri: Uri): String {
        val tmp = File(ctx.cacheDir, "incoming.zip")
        val input = ctx.contentResolver.openInputStream(zipUri) ?: throw Exception("No se pudo abrir el archivo")
        input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }

        return ZipFile(tmp).use { z ->
            val propEntry = z.getEntry("module.prop") ?: throw Exception("El zip no tiene module.prop")
            val props = parseProps(z.getInputStream(propEntry).bufferedReader().readText())
            val id = props["id"] ?: throw Exception("module.prop no tiene id")
            if (!SAFE_ID.matches(id)) throw Exception("El id del módulo no es válido")
            val bannerName = props["banner"]?.removePrefix("./")

            val dest = "$DEPLOY/$id"
            val r0 = Shell.run("rm -rf '$dest' && mkdir -p '$dest' && chmod 755 '$DEPLOY' '$dest'")
            if (r0.code != 0) throw Exception("No se pudo crear $dest (¿motor sin permisos?): ${r0.err.trim()}")

            val ui = uiDir(ctx, id); ui.deleteRecursively(); ui.mkdirs()
            val mdir = File(modsDir(ctx), id); mdir.deleteRecursively(); mdir.mkdirs()

            var totalBytes = 0L
            var hasAction = false
            var bannerSaved = false
            for (e in z.entries().toList()) {
                if (e.isDirectory) continue
                val name = e.name
                if (name.contains("..") || !SAFE.matches(name)) continue
                val bytes = z.getInputStream(e).readBytes()
                totalBytes += bytes.size
                if (name == "action.sh") hasAction = true
                if (!bannerSaved && (name == bannerName || BANNER_NAMES.contains(name.lowercase())) && bytes.size > 200) {
                    File(mdir, "banner.img").writeBytes(bytes)
                    bannerSaved = true
                }
                val path = "$dest/$name"
                val dir = path.substringBeforeLast('/')
                val r = Shell.run("mkdir -p '$dir' && cat > '$path' && chmod 755 '$path'", bytes)
                if (r.code != 0) throw Exception("Falló al copiar $name: ${r.err.trim()}")
                if (name.startsWith("webroot/")) {
                    val f = File(ui, name.removePrefix("webroot/"))
                    f.parentFile?.mkdirs(); f.writeBytes(bytes)
                }
            }
            File(mdir, "module.prop").writeBytes(z.getInputStream(propEntry).readBytes())
            prefs(ctx).edit()
                .putLong("size_$id", (totalBytes + 1023) / 1024)
                .putBoolean("act_$id", hasAction)
                .putBoolean("bn_$id", true)
                .apply()
            id
        }
    }

    fun start(id: String): ExecResult =
        Shell.run("cd '$DEPLOY/$id' && [ -f service.sh ] && (nohup sh '$DEPLOY/$id/service.sh' >/dev/null 2>&1 &) ; echo started")

    fun stop(id: String): ExecResult =
        // el corchete en [a]xr evita que pgrep encuentre (y mate) al propio shell que lo ejecuta
        Shell.run("for p in \$(pgrep -f '/data/local/tmp/[a]xr/${id.replace(".", "\\.")}/service\\.sh'); do kill \$p; done; echo stopped")

    fun action(id: String): ExecResult =
        Shell.run("cd '$DEPLOY/$id' && [ -f action.sh ] && sh '$DEPLOY/$id/action.sh'")

    fun remove(ctx: Context, id: String) {
        Shell.run("[ -f '$DEPLOY/$id/uninstall.sh' ] && sh '$DEPLOY/$id/uninstall.sh'; rm -rf '$DEPLOY/$id'")
        File(modsDir(ctx), id).deleteRecursively()
        uiDir(ctx, id).deleteRecursively()
        customBannerFile(ctx, id).delete()
        prefs(ctx).edit().remove("size_$id").remove("act_$id").remove("bn_$id").remove("en_$id").apply()
    }
}
